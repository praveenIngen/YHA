<!-- Script Constant define -->
<script>
    var PATH = new Object();
    PATH.SITE = "<?php echo PATH_SITE;?>";
    PATH.THEME_IMG = "<?php echo PATH_THEME_IMG;?>";
    var SITE = new Object();
    SITE.URL = "<?php echo SITE_URL;?>";
    SITE.THEME_IMG = "<?php echo SITE_PATH_THEME_IMG;?>";
    var STATUS = new Object();
    STATUS.SUCESS = "<?php echo Enum::HttpStatus()->OK;?>";
    STATUS.FAILED = "<?php echo Enum::HttpStatus()->ERROR;?>";
    var MSG = new Object();
    MSG.SUCESS = "Action Completed!";
    MSG.FAILED = "Action Could Not Be Completed!";
</script>
