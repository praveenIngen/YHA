<?php
/**
* 
*/
class ApiConstantsBase
{
	const BASE_URL =  "http://103.25.130.94/api/";

	public static function HostelApi()
	{
		$HOTEL_API	 = array(
          "BASE_URL"=>apiConstantsBase::BASE_URL,
          "GET_HIGHTLIGHT_HOTELS"=>"api/spaces/",
        );
        return (object)$HOTEL_API;
	}

	public static function MasterApi()
	{
		$MASTER_API	 = array(
          "BASE_URL"=>apiConstantsBase::BASE_URL,
          "GET_CITIES"=>"api/mobile/masterdata/",
          "GET_STATE_CITIES"=>"/api/masterdata/cities/"
        );
        return (object)$MASTER_API;
	}

	public static function MemberShipApi()
	{
		$MEMBERSHIP_API	 = array(
          "BASE_URL"=>"http://103.25.130.94/Membership/api",
          "POST"=>"/api/mobile/members?documentContainerModel=",
          "PUT"=>"api/OnlineMemberShipPut",
          "MasterGet" =>"/api/masterdata/",
         /* "GetState" =>"http://103.25.130.94/Membership/api/api/masterdata",*/

        );
        return (object)$MEMBERSHIP_API;
	}

	public static function InternationalHostels()
	{
		$INTERNSTIONAL_API = array(
			"BASE_URL"=>"https://affiliates.hihostels.com/",
          	"GET_CITIES"=>"update_selections?lang=E",
		);
		return (object)$INTERNSTIONAL_API;
	}
}

class ApiConstants extends apiConstantsBase{
}

$OBJ_API_CONSTANTS = new ApiConstants();
?>
