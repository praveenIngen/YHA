<?php
function pre($data) {
    echo '<div style="width:100%; border:2px solid #f00;"><pre>';
    print_r($data);
    echo '</pre></div>';
}

function prexit($data) {
    echo '<div style="width:100%; border:2px solid #f00;"><pre>';
    print_r($data);
    echo '</pre></div>';
    die;
}

function DebugData($data)
{
    $myfile = fopen(PATH_BASE."\debug.txt", "w");
    $txt = $data."\n";
    fwrite($myfile, $txt);
    fclose($myfile);
}

function ApiDebug($data)
{
    $myfile = fopen(PATH_BASE."\apiDebugLog.txt", 'a') or die('Cannot open file:  ');
    $txt = $data."\n";
    fwrite($myfile, $txt);
    fclose($myfile);
}

function IsNull($data)
{
	if($data===null || $data=="")
		return true;
	else
		return false;
}
?>