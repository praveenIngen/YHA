<?php 

class Entity { 
	
	function __construct() {	
	   include_once("enum/Enum.php");// To include Enum files
	   include_once("constants/apiConstants.php");// To include api files
	   include_once("constants/Constants.php");// To include api files
	   include_once("constants/constantFunctions.php");// To include api files
	   include_once("coreAPI/ServiceManager.php");// To include API file to hit the server	
   }
}
$ENTITY = new  Entity();
?>