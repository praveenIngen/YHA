<?php
 /**
 *Please ensure that you have include entity.php on your page 
 */

 class InternationalHostelsRepository 
 {
 	
 	function __construct()
 	{ 		

 	}

 	function PostCountryToGetCities($data)
 	{
 		$Response =  array();
 		$Response = (object)$Response;
 		if($data!=null && !empty($data))
 		{
 			$API_Route = apiConstants::InternationalHostels()->BASE_URL.apiConstants::InternationalHostels()->GET_CITIES;
 			$Response =  ServiceManager::Post($API_Route,$data,false);
 		}
 		else
 		{
 			$Response->StatusCode = Enum::HttpStatus()->OK;
 			$Response->ServicePayload = null;
 			$Response->ErrorMessage = "Data Can Not Be Null!";
 		}
 		return $Response;
 	}
 }
$INTERNATIONAL_HOSTELS_REPOSITORY  = new InternationalHostelsRepository();
?>