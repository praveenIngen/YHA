<?php
 /**
 *Please ensure that you have include entity.php on your page 
 */

 class highLightHotelsRepository 
 {
 	
 	function __construct()
 	{ 		

 	}

 	function GetHotelById($id)
 	{
 		$API_Route = apiConstants::HostelApi()->BASE_URL.apiConstants::HostelApi()->GET_HIGHTLIGHT_HOTELS.$id;
 		$response =  ServiceManager::Get($API_Route,true);
 		return $response;
 	}
 }
$OBJ_HIGHLIGHT_HOTEL_REPOSITORY = new highLightHotelsRepository();
?>