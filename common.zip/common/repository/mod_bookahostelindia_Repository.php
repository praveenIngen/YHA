<?php
 /**
 *Please ensure that you have include entity.php on your page 
 */

 class mod_bookahostelindia_Repository 
 {
 	
 	function __construct()
 	{ 		

 	}

 	function GetMasterData()
 	{
 		$API_Route = apiConstants::MasterApi()->BASE_URL.apiConstants::MasterApi()->GET_CITIES;
 		$Cities =  ServiceManager::Get($API_Route,true);
 		return $Cities;

 	}

 	function GetStateCities($stateid)
 	{
 		$API_Route = apiConstants::MasterApi()->BASE_URL.apiConstants::MasterApi()->GET_STATE_CITIES.$stateid;
 		$Cities =  ServiceManager::Get($API_Route,true);
 		return $Cities;
 	}
 }
$MOD_BOOKAHOSTELINDIA_REPOSITORY = new mod_bookahostelindia_Repository();
?>