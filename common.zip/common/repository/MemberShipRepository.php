<?php
 /**
 *Please ensure that you have include entity.php on your page 
 */

 class MemberShipRepository 
 {
 	
 	function __construct()
 	{ 		

 	}

 	function GetMemberMasterData()
 	{ 
 		$Response =  array();
 		$Response = (object)$Response;
 		$API_Route = apiConstants::MemberShipApi()->BASE_URL.apiConstants::MemberShipApi()->MasterGet."/".$data;
 		 $response = ServiceManager::Get($API_Route,null);
        $Response->StatusCode = $response->StatusCode==Enum::HttpStatus()->StatusCode->OK?Enum::HttpStatus()->Ok:Enum::HttpStatus()->ERROR;
		$Response->ServicePayload = $response->ServicePayload;
		$Response->ErrorMessage = $response->ErrorMessage;
 		return $Response;
 	}

 	function Get($data)
 	{
 		$Response =  array();
 		$Response = (object)$Response;
 		if($data!=null && !empty($data))
 		{
 			$API_Route = apiConstants::MemberShipApi()->BASE_URL.apiConstants::MemberShipApi()->GET."/".$data;
 			$Response =  ServiceManager::Get($API_Route,null);
 		}
 		else
 		{
 			$Response->StatusCode = Enum::HttpStatus()->OK;
 			$Response->ServicePayload = null;
 			$Response->ErrorMessage = "Data Can Not Be Null!";
 		}
 		return $Response;
 	}

 	function Post($data)
 	{
 		$Response =  array();
 		$Response = (object)$Response;
 		if($data!=null && !empty($data))
 		{
 			
 			$API_Route = apiConstants::MemberShipApi()->BASE_URL.apiConstants::MemberShipApi()->POST;
 			$API_Routes = sprintf("%s%s", $API_Route, http_build_query((array)json_decode($data)));
 			$API_Routes = "http://103.25.130.94/Membership/api/api/mobile/members?documentContainerModel=null";
 		 	$Response =  ServiceManager::Post($API_Routes,null,true);
 		 	pre($Response);
 		 	die;
        }
 		else
 		{
 			$Response->StatusCode = Enum::HttpStatus()->OK;
 			$Response->ServicePayload = null;
 			$Response->ErrorMessage = "Data Can Not Be Null!";
 		}
 		return $Response;
 	}

 	//put 
 	function Put($data)
 	{
 		$Response =  array();
 		$Response = (object)$Response;

 		if($data!=null && !empty($data))
 		{
 			$API_Route = apiConstants::MemberShipApi()->BASE_URL.apiConstants::MemberShipApi()->PUT;
 			$Response =  ServiceManager::Post($API_Route,$data);
 		}
 		else
 		{
 			$Response->StatusCode = Enum::HttpStatus()->OK;
 			$Response->ServicePayload = null;
 			$Response->ErrorMessage = "Data Can Not Be Null!";
 		}
 		return $Response;
 	}
 }
$MEMBERSHIP_REPOSITORY  = new MemberShipRepository();
?>