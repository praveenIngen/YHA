<!--main js file start-->  
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/datetimepicker/jquery.datetimepicker.js"></script> 
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/parallax/jquery.parallax-1.1.3.js"></script> 
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/owl/owl.carousel.js"></script> 
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/isotope/jquery.isotope.js"></script> 
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/bxslider/jquery-bxslider.js"></script> 
<!-- pie chart js -->
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/pie-circle/circles.js"></script> 
<!-- pie chart js -->
<!--counter js-->
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/counter/jquery.countTo.js">
</script>
 <!--counter js-->
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/counter/jquery.countdown.js"></script>
 <!--dialog js-->
<script type="text/javascript" src="<?php echo SITE_PATH_WEBROOT ?>/Scripts/metroJs/metro.js"></script>
	<!-- REVOLUTION JS FILES -->
   <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/revolution/js/jquery.themepunch.tools.min.js">
    </script>
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/revolution/js/jquery.themepunch.revolution.min.js">
    </script>
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/revolution/js/revolution.extension.layeranimation.min.js">
    </script>
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/revolution/js/revolution.extension.navigation.min.js">
    </script>
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/revolution/js/revolution.extension.slideanims.min.js">
    </script>
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/revolution/js/revolution.extension.actions.min.js">
    </script>
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/revolution/js/revolution.extension.parallax.min.js">
    </script>
    <!-- REVOLUTION JS FiLES -->
    <!-- video_popup -->
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/video-popup/jquery.magnific-popup.js">
    </script>
    <!-- video_popup -->
 
    <!--slick slider -->
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/slick/jquery-migrate-1.2.1.min.js">
    </script>
    <script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/slick/slick.min.js"></script>
    <!-- slick slider -->
    <!-- video player js -->
    <script src="<?php echo SITE_PATH_THEME_JS ?>/plugin/video_player/mediaelement-and-player.min.js"></script>
    <!-- video player js -->
	
	<!-- pricefilter -->
	<script src="<?php echo SITE_PATH_THEME_JS ?>/plugin/jquery-ui/jquery-ui.js"></script>
	<!-- pricefilter-->
	<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/custom.js"></script> 
	<!--main js file end-->

    <!-- Css for loader -->
    <link rel="Stylesheet" href="<?php echo SITE_PATH_WEBROOT ?>/Css/loader/loader.css" type="text/css" />