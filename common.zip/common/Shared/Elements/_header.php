<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="keywords" content="<?php echo $objBase->getMetaData('keywords') ?>" />
<meta name="description" content="<?php echo $objBase->getMetaData('description') ?>" />
<meta name="generator" content="YHAI" />
<!-- Include Css -->
<link rel="Stylesheet" href="<?php echo SITE_PATH_THEME_CSS ?>/main.css" type="text/css" />
<link rel="Stylesheet" href="<?php echo SITE_PATH_WEBROOT ?>/Css/custom_new.css" type="text/css" />
<link rel="Stylesheet" href="<?php echo SITE_PATH_WEBROOT ?>/Css/custom_mediaquery.css" type="text/css" />
<link rel="Stylesheet" href="<?php echo SITE_PATH_WEBROOT ?>/Css/bootstrap.min.css">
<link  rel="Stylesheet" href="<?php echo SITE_PATH_WEBROOT ?>/Css/bootstrap-theme.min.css">
<link rel="Stylesheet" href="<?php echo SITE_PATH_WEBROOT ?>/Css/metroCss/metro.css" type="text/css" />
<!-- Main Js Start-->
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/jquery-1.11.3.js"></script>
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/bootstrap.js"></script> 
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/bootstrap-select.js"></script> 
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/jquery-validator/jquery.validate.min.js"></script>
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/jquery-validator/additional-methods.js"></script>
<script type="text/javascript" src="<?php echo SITE_PATH_WEBROOT ?>/Scripts/appValidation.js"></script>
<script type="text/javascript" src="<?php echo SITE_PATH_WEBROOT ?>/Scripts/common.js"></script>
<!-- Main Js Ended -->
 <!--slick slider -->
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/slick/jquery-migrate-1.2.1.min.js">
    </script>
<script type="text/javascript" src="<?php echo SITE_PATH_THEME_JS ?>/plugin/slick/slick.min.js"></script>
    <!-- slick slider -->
<!-- favicon links -->
<link rel="shortcut icon" type="image/ico" href="favicon.ico" />
<link rel="icon" type="image/ico" href="favicon.ico" />
<?php include_once(PATH_COMMON . "/constants/scriptConstants.php"); ?>