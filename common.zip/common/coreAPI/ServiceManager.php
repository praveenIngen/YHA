<?php
/**
* 
*/
class ServiceManagerBase
{
	
	//function to Get method
	public static function Get($url,$data=null,$convertToJson = true)
	{
		$serviceManagerBase = new ServiceManagerBase();
		if($convertToJson)
			return json_decode($serviceManagerBase->CallAPI("GET", $url, $data));
		else
			return $serviceManagerBase->CallAPI("GET", $url, $data);
	}
	
	//post data
	public static function Post($url, $data = false,$convertToJson = true)
	{

		$serviceManagerBase = new ServiceManagerBase();
      
	
		if($convertToJson)

			return json_decode($serviceManagerBase->CallAPI("POST", $url, $data));

		else
			return $serviceManagerBase->CallAPI("POST", $url, $data);
	}



	//Put data
	public static function Put($url, $data = false,$convertToJson = true)
	{
		$serviceManagerBase = new ServiceManagerBase();
		if($convertToJson)
			return json_decode($serviceManagerBase->CallAPI("PUT", $url, $data));
		else
			return $serviceManagerBase->CallAPI("PUT", $url, $data);
	}

	//call api
    private function CallAPI($method, $url, $data = false)
	{
		echo $url." ".$method;
		//debug post data
		if($method=="POST" || $method=="PUT")
			DebugData($method."\n\n\n\t".$data);
	     $curl = curl_init($url);
	    switch ($method)
	    {
	        case "POST":
	            curl_setopt($curl, CURLOPT_POST, 1);
				curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");  
		        if ($data)
		            {
		            	curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
	                	curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
		       
		            }    
		            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true); 
	            break;
	        case "PUT":
	            curl_setopt($curl, CURLOPT_PUT, 1);
	            break;
	        default:
	            if ($data)
	                $url = sprintf("%s?%s", $url, http_build_query($data));
	    }
	    $curl = curl_init($url);
	    // Optional Authentication:
	    curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
	    curl_setopt($curl, CURLOPT_USERPWD, "username:password");

	    $headers= array('Accept: application/json','Content-Type: application/json'); 
	    curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
	    curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);

	    $result = curl_exec($curl);

	    curl_close($curl);
	    
	    
	    return $result;
	


	    
	}
}

class ServiceManager extends ServiceManagerBase{
}
$SERVICE_MANAGER = new ServiceManager();
?>
