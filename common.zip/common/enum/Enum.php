<?php
/**
* 
*/
class SplEnumPlus
{
	const API_BASE_URL     = "http://103.25.130.94/api/";
  	const TANENT_ID        = 1;
 	const COUNTRY_ID       = 1;
  	const NEW_DELHI        = 17853;

  	public static function ArrayToJson($data)
  	{
  	 	return json_decode(json_encode($data));
  	}
  	
  	public static function HttpStatus()
  	{
  		$HTTPSTATUS	 = array(
              "OK"=>"SUCCESS",
              "ERROR"=>"FAILED",
              "StatusCode"=>array(
                "OK"=>200,
                "BAD_REQUEST"=>"",
              )
            );
  		return SplEnumPlus::ArrayToJson($HTTPSTATUS);
  	}

    public static function Hotels()
    {
      $HOTELS = array(
         "NEW_DELHI"=> 5102, 
        "MANALI"  => 5042,
        "LEH"    => 16677,
      );
      return  SplEnumPlus::ArrayToJson($HOTELS);
    }
  	public static function Country()
  	{
  		$COUNTY = array(
  				"INDIA"=>1,
  			);
  		return  SplEnumPlus::ArrayToJson($COUNTY);
  	}

  	public static function City()
  	{
  		$City = array(
  			"NEW_DELHI" => 17853,
  		);
  		return  SplEnumPlus::ArrayToJson($City);
  	}

    public static function Gender()
    {
      $Gender = array(
        "MALE" => 1,
        "FEMALE" => 2,
      );
      return  SplEnumPlus::ArrayToJson($Gender);
    }

    public static function AppLinks(){
      $Apps = array(
          "ANDROID"=>"https://play.google.com/store/apps/details?id=com.yha.ingen.hmbs.androidapp&hl=en",
          "IPHONE" =>"https://appsto.re/in/nPuFab.i",
          "FACEBOOK" =>"https://www.facebook.com/youthhostelassociationofindia",
          "TWITTER" =>"http://twitter.com/yhaindia",
          "GOOGLE" =>"http://picasaweb.google.com/yhaindia",
          "YOUTUBE"=> "https://www.youtube.com/yhaindia",
          "INSTAGRAM"=> "https://www.instagram.com/yhaindia/",
          "FEEDBACK" =>"http://yhaindia.org/enquiry-form.php",
        );
      return  SplEnumPlus::ArrayToJson($Apps);
    }

  	public static function SubmitForms()
  	{
  		$Forms = array(
  				/*For Production Server*/
  				//"MOD_BOOKHOSTELINDIA_POST" => "https://hotelingen.com/yhai/Rooms/Search/",
  				//"EBS_POST"=>"https://hotelingen.com/payment/mobile/index",
          "GET_RESERVATION_DETAILS"=>"https://hotelingen.com/yhai/Reservations/Details",
  				/*For Stage Server*/
  				"MOD_BOOKHOSTELINDIA_POST" => "http://122.160.200.32/hotelingen/Rooms/Search/",
  				 "EBS_POST"=>"http://122.160.200.32/payment/mobile/index",
           "INTERNATIONAL_HOSTEL"=>"https://affiliates.hihostels.com//search",
  			);
  		return  SplEnumPlus::ArrayToJson($Forms);
  	}
    public static function InternationalHostels()
    {
      $INTERNATIONAL = array(
          "GET_HOSTELS" => "https://affiliates.hihostels.com/search-box?lang=E&linkid=980076",
          "GET_INTERNATIONAL_CITIES"=>"https://affiliates.hihostels.com/update_selections?lang=E",
           "INDIA_VAL"=>"in",
        );
      return  SplEnumPlus::ArrayToJson($INTERNATIONAL);
    }
    //home slider images
    public static function GetHomeSliderImages()
    {
      $HomeSliderImages = array("Chanderkhani_2.jpg","Dalhousie_Trekking.jpg","Desert_Family_Camping_(2).jpg","DSCN8427.jpg","Jim_Corbett_Cycling_(2).jpg","Kedarkantha_(3).jpg","Mountain_Biking_Girls.jpg","SarPass_6.jpg");
      return  $HomeSliderImages;
    }

    public static function ProgramTransportTypes()
    {
      $ProgramTransportTypes = array(
          "GOING_TO" => 1,
          "RETURNING_FROM"=>2,
           "BOTH_WAY"=>3,
        );
      return  SplEnumPlus::ArrayToJson($ProgramTransportTypes);
    }

    public static function Status()
    {
      $Status = array(
          "ACTIVE" => "A",
          "IN_ACTIVE"=>"I",
           "CANCELLED"=>"C",
        );
      return  SplEnumPlus::ArrayToJson($Status);
    }

    public static function SmsAction()
    {
      $SmsAction = array(
            "BASE_URL" => "http://msg.msgclub.net/rest/services/sendSMS/sendGroupSms",
            "AUTH_KEY" => "932db57f14338a9692b694b42c955b1",
            "ROUTE_ID" => 1,
            "SENDER_ID" => 'INGENS',
            "CONTENT_TYPE" =>'English',
             );
       return  SplEnumPlus::ArrayToJson($SmsAction);
    }
}

class Enum extends SplEnumPlus{
}

$ENUM = new Enum();
?>