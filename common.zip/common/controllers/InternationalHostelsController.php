 <?php
//include highLightHotelsRepository repo
include_once(PATH_REPOSITORYS."/InternationalHostelsRepository.php");
/**
* 
*/
class InternationalHostelsController
{
	
	function GetCountryCities($data)
	{
		global $INTERNATIONAL_HOSTELS_REPOSITORY;
	 	$ApiResponse = $INTERNATIONAL_HOSTELS_REPOSITORY->PostCountryToGetCities($data);
	 	$returnObj = array();   
	 	if($ApiResponse!=null)
        {
            $returnObj = array("Result"=>$ApiResponse);
            $returnObj = array("Msg"=>"Ok");
        }
        else{
        	$returnObj = array("Result"=>null);
        	$returnObj = array("Msg"=>"unble to get server!" );
        }
        return $returnObj;
	}
}
$INTERNATIONAL_HOSTELS_CONTROLLER = new  InternationalHostelsController();
?>