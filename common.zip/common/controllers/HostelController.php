 <?php
//include highLightHotelsRepository repo
include(PATH_REPOSITORYS."/highLightHotelsRepository.php");
/**
* 
*/
class HostelController
{
	
	function getHighLightHostels()
	{
		global $OBJ_HIGHLIGHT_HOTEL_REPOSITORY;
		global $objBase;
		//Get highlight hotels
		$defaultHotel = (object)array(
			"SpaceName"=> "",
			"BinaryFileBasePath"=>SITE_URL,
			"SpaceImage" => SITE_DEFAULT_IMAGE_PATH, 
			"SpaceName" =>""
		);

		$highlightHotel = array();

		$highlightHotel["NewDelhi"] = $OBJ_HIGHLIGHT_HOTEL_REPOSITORY->GetHotelById((int)Enum::Hotels()->NEW_DELHI);
		$highlightHotel["Manali"] = $OBJ_HIGHLIGHT_HOTEL_REPOSITORY->GetHotelById((int)Enum::Hotels()->MANALI);
		$highlightHotel["Leh"] = $OBJ_HIGHLIGHT_HOTEL_REPOSITORY->GetHotelById((int)Enum::Hotels()->LEH);
		if($highlightHotel!=null && !empty($highlightHotel)){
			foreach ($highlightHotel as $key => $value) {
				if($value!=null && !empty($value) && $value->ServicePayload!=null && !empty($value->ServicePayload)){
						$highlightHotel[$key] = $value->ServicePayload;
						if($value->ServicePayload->SpaceImage!=null && $value->ServicePayload->SpaceImage!="")
						{
							$highlightHotel[$key] = $objBase->addNewPropertyTo($highlightHotel[$key], array("BinaryFileBasePath"=> $value->BinaryFileBasePath));
						}else{
							$highlightHotel[$key]->SpaceImage = $defaultHotel->SpaceImage;
							$highlightHotel[$key] = $objBase->addNewPropertyTo($highlightHotel[$key], array("BinaryFileBasePath"=> $defaultHotel->BinaryFileBasePath));
						}
					}
					else{
						$highlightHotel[$key] = $defaultHotel;
					}
				}
			}
		return 	$highlightHotel;
	}
}
$OBJ_HOSTEL_CONTROLLER = new  HostelController();
?>