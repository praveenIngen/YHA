 <?php
//include highLightHotelsRepository repo
include(PATH_REPOSITORYS."/mod_bookahostelindia_Repository.php");
include(PATH_REPOSITORYS."/MEMBERSHIP_REPOSITORY.php");
/**
* 
*/
class MasterController
{
	
	function getHostelCites()
	{
		global $MOD_BOOKAHOSTELINDIA_REPOSITORY;
	    //variable also used in footer;
	    $Cities = $MOD_BOOKAHOSTELINDIA_REPOSITORY->GetMasterData();
	    $City_Options = "";
	    if($Cities !=null && isset($Cities ) && !empty($Cities )){

	        if(!empty($Cities ->ServicePayload->CITY)){
	        
	            foreach($Cities ->ServicePayload->CITY as $hb_city){    
	                if($hb_city->Value==Enum::City()->NEW_DELHI)
	                $City_Options .= '<option value="'.$hb_city->Value.'" selected>'.$hb_city->Text.'</option>';
	                else
	                $City_Options .= '<option value="'.$hb_city->Value.'">'.$hb_city->Text.'</option>';

	            }

	        }
	    }
	    return $City_Options;
	}

	function MembershipMasterData()
	{

		global $MEMBERSHIP_REPOSITORY;
	    //variable also used in footer;
	    $MembershipMasterData = $MEMBERSHIP_REPOSITORY->GetMemberMasterData();
	    return $MembershipMasterData;
	  }

	  function GetMemberShipType($data)
	  {
	  	 global $MEMBERSHIP_REPOSITORY;
        $membership_options = "";
        //variable also used in footer;
        $MembershipType = $this->MembershipMasterData($MembershipMasterData);
        if($MembershipType !=null && isset($MembershipType ) && !empty($MembershipType )){
          if(!empty($MembershipType->ServicePayload->MEMBERSHIP_TYPE )){
           foreach($MembershipType->ServicePayload->MEMBERSHIP_TYPE as $hb_membership_type){
                if($MembershipType->ServicePayload->MEMBERSHIP_TYPE->Selected){
                      $membership_options .= '<option value="'.$hb_membership_type->Value.'" selected>'.$hb_membership_type->Text.'</option>';
                  }else{
                     $membership_options .= '<option value="'.$hb_membership_type->Value.'">'.$hb_membership_type->Text.'</option>';
                  } 
                }
             }        //die($objDB->getQuery());
        }
        return $membership_options;

	  }

	  function GetState($data)
	  {
          global $MEMBERSHIP_REPOSITORY;
        $state_options = "";
        //variable also used in footer;
        $States = $this->MembershipMasterData($MembershipMasterData);
         if($States !=null && isset($States ) && !empty($States )){
           if(!empty($States->ServicePayload->STATE )){
              foreach($States->ServicePayload->STATE as $hb_state_id){
                if($States->ServicePayload->STATE->Selected){

                      $state_options .= '<option value="'.$hb_state_id->Value.'" selected>'.$hb_state_id->Text.'</option>';
                  }else{
                     $state_options .= '<option value="'.$hb_state_id->Value.'">'.$hb_state_id->Text.'</option>';
                  } 
                }
             } 
             //die($objDB->getQuery());
        }
        return $state_options;

	  }  
	 function GetCities($StateID)
	  {
	  	global $MOD_BOOKAHOSTELINDIA_REPOSITORY;
	  	$city_option = "<option value''></option>";
        if($StateID!=0 && $StateID!=null)
        {
        	//call 
        	$Cities = $MOD_BOOKAHOSTELINDIA_REPOSITORY->GetStateCities($StateID);
        	if($Cities !=null && isset($Cities ) && !empty($Cities )){
	           	if(!empty($Cities->ServicePayload )){
	              foreach($Cities->ServicePayload as $hb_state_id){
	                if($hb_state_id->Selected){
	                      $city_option .= '<option value="'.$hb_state_id->Value.'" selected>'.$hb_state_id->Text.'</option>';
	                  }else{
	                     $city_option .= '<option value="'.$hb_state_id->Value.'">'.$hb_state_id->Text.'</option>';
	                  } 
	                }
             	} 
             //die($objDB->getQuery());
        	}
        }
        return $city_option;
	  }

}
$OBJ_MASTER_CONTROLLER = new  MasterController();
?>