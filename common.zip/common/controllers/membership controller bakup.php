<?php
//include MemberShipController controller
include_once(PATH_REPOSITORYS."/MemberShipRepository.php");

class MemberShipController {

    public $returnObj = array("status"=>"","data"=>"","Msg"=>""); 

    private function FilterPostData($data)
    {
        $data = json_decode($data);
        $obj = (object)array();
        if($data!=null && !empty($data))
        {
            $obj->id = $data->id;
            $obj->member_id = $data->member_id;
            $obj->email = $data->email;
            $obj->member_plan_id = $data->member_plan_id;
            $obj->plan_code = $data->plan_code;
            $obj->plan_code_old = $data->plan_code_old;
            $obj->plan_category = $data->plan_category;
            $obj->membership_number = $data->membership_number;
            $obj->fname = $data->fname;
            $obj->lname = $data->lname;
            $obj->gender = $data->gender;
            $obj->address1 = $data->address1;
            $obj->address2 = $data->address2;
            $obj->address3 = $data->address3;
            $obj->phone = $data->phone;
            $obj->mobile = $data->mobile;
            $obj->photograph = $data->photograph;
            if($data->country=="IND")
            {
                $obj->country = "INDIA";    
            }else{
                $obj->country = $data->country;
            }
            $obj->state = $data->state;
            $obj->city = $data->city;
            $obj->postal_code = $data->postal_code;
            $obj->unit = $data->unit;
            $obj->unit_name = $data->unit_name;
            $obj->dob = $data->dob;
            $obj->date_of_birth = $data->date_of_birth;
            $obj->valid_from = $data->valid_from;
            $obj->valid_to = $data->valid_to;
            $obj->status = $data->status;
            $obj->id = $data->id;
            $obj->type = $data->type;
            $obj->old_membership_number = $data->old_membership_number;
            $obj->new_membership_number = $data->new_membership_number;
            $obj->exp_date = $data->exp_date;
            $obj->online_membership_card = $data->online_membership_card;
            $obj->offline_membership_card = $data->offline_membership_card;
        }
        $obj = json_encode($obj);
        return $obj;
    }

    function Get($memberCode)
    {
        global $MEMBERSHIP_REPOSITORY;
        $ApiResponse = $MEMBERSHIP_REPOSITORY->Get($memberCode); 
        //pre($ApiResponse );  
        if($ApiResponse!=null)
        {
            if($ApiResponse->StatusCode==Enum::HttpStatus()->StatusCode->OK && $ApiResponse->ServicePayload !=null && !empty($ApiResponse->ServicePayload))
            {
                $returnObj["status"] = true;
                $returnObj["data"] = $ApiResponse->ServicePayload;;
            }else{
                $returnObj["status"] = false;
                $returnObj["data"] = null;
                $returnObj["msg"] = $ApiResponse->ErrorMessage;
            }
        }
        else{
            //log file
            //$error = "Get: {DATA}".($memberCode)."\n {RESPONSE}".json_encode($ApiResponse);
            //ApiDebug($error);
            $returnObj["status"] = false;
            $returnObj["data"] = null;
            $returnObj["msg"] = "unble to get our server!";
        }
        return (object)$returnObj;   
    }
		
	function Post($data)
	{
		global $MEMBERSHIP_REPOSITORY;
        $data = $this->FilterPostData($data);
	 	$ApiResponse = $MEMBERSHIP_REPOSITORY->Post($data);	
	 	$returnObj = array();   
	 	if($ApiResponse!=null)
        {
            if($ApiResponse->StatusCode==Enum::HttpStatus()->StatusCode->OK && $ApiResponse->ServicePayload !=null && !empty($ApiResponse->ServicePayload))
            {
                $returnObj["status"] = true;
                $returnObj["data"] = $ApiResponse->ServicePayload;
            }else{
                //log file
                $error = "POST: {DATA}".($data)."\n {RESPONSE}".json_encode($ApiResponse);
                ApiDebug($error);
                $returnObj["status"] = false;
                $returnObj["data"] = null;
                $returnObj["msg"] = $ApiResponse->ErrorMessage;
            }
        }
        else{
            //log file
            $error = "POST: {DATA}".($data)."\n {RESPONSE}".json_encode($ApiResponse);
            ApiDebug($error);
            $returnObj["status"] = false;
            $returnObj["data"] = null;
            $returnObj["msg"] = "unble to get server!";
        }
        return (object)$returnObj;
	}

	function Put($data)
	{
		global $MEMBERSHIP_REPOSITORY;
        $data = $this->FilterPostData($data);
	 	$ApiResponse = $MEMBERSHIP_REPOSITORY->Put($data);	
	 	$returnObj = array();   
	 	if($ApiResponse!=null)
        {
            if($ApiResponse->StatusCode==Enum::HttpStatus()->StatusCode->OK && $ApiResponse->ServicePayload !=null && !empty($ApiResponse->ServicePayload))
            {
            	$returnObj = array("Id"=>true);
                $returnObj["status"] = true;
                $returnObj["data"] = true;
            }else{
                //log file
                $error = "PUT: {DATA}".($data)."\n {RESPONSE}".json_encode($ApiResponse);
                ApiDebug($error);
                $returnObj["status"] = false;
                $returnObj["data"] = null;
                $returnObj["msg"] = $ApiResponse->ErrorMessage;
            }
        }
        else{
            //log file
            $error = "PUT:  {DATA}".($data)."\n {RESPONSE}".json_encode($ApiResponse);
            ApiDebug($error);
        	$returnObj["status"] = false;
            $returnObj["data"] = null;
            $returnObj["msg"] = "unble to get server!";
        }
        return (object)$returnObj;   
	}
}
$MEMBERSHIP_CONTROLLER = new MemberShipController();