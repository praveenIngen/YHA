<?php
//include MemberShipController controller
include_once(PATH_REPOSITORYS."/MemberShipRepository.php");

class MemberShipController {

    public $returnObj = array("status"=>"","data"=>"","Msg"=>""); 

    private function FilterPostData($data)
    {
        $data = json_decode($data);
        $obj = (object)array();
        if($data!=null && !empty($data))
        {

        $membershipArray=  array(
                "id" => $data->id,
                "MemberId" => $data->MemberId,         
          "MemberShipTypeId" => $data->MEMBERSHIP_TYPE,
           "MembershipCode"  => $data->MembershipCode,      
              "Person" => array(
                    "FirstName"=> $data->FirstName,
                     "LastName"=>$data->LastName,
                     "EmailAddress"=>$data->EmailAddress,
                     "GenderId"=>$data->GenderId,
                     "AltContact"=>$data->AltContact,
                     "Contact"=>$data->Contact,
                      "DOB" => $data->DOB,
                     "PersonAddress" => array(
                        "AddressLineOne" =>$data->AddressLineOne,
                        "AddressLineTwo"=>$data->AddressLineTwo,
                        "AddressLineThree"=>$data->AddressLineThree, 
                        "StateID"=>$data->StateID,
                        "CityID"=>$data->CityID,
                        "PostalCode"=>$data->PostalCode,
                        "CountryID"=>$data->country,
                        ),
                    ),
              );
             
               /* $obj->FirstName = $data->fname;
                $obj->LastName = $data->lname;
                $obj->EmailAddress = $data->email;
                $obj->GenderId = $data->gender;
                $obj->AltContact = $data->phone;
                $obj->Contact = $data->mobile;
                $obj->DOB = $data->dob;
                $obj->date_of_birth = $data->date_of_birth; 
                $obj->AddressLineOne  = $data->address1;
                $obj->AddressLineTwo  = $data->address2;
                $obj->AddressLineThree  = $data->address3;
                $obj->StateID  = $data->state;
                $obj->CityID  = $data->city;
                $obj->PostalCode = $data->postal_code;
                if($data->country=="IND")
                {
                    $obj->country = "INDIA";    
                }else{
                    $obj->CountryID  = $data->country;
                }  */       
                
                      
        } 
   
              
         $obj = json_encode($membershipArray); 
         pre($obj);   
        return $obj;
    }

    function Get($memberCode)
    {
        global $MEMBERSHIP_REPOSITORY;
        $ApiResponse = $MEMBERSHIP_REPOSITORY->Get($memberCode); 
        //pre($ApiResponse );  
        if($ApiResponse!=null)
        {
            if($ApiResponse->StatusCode==Enum::HttpStatus()->StatusCode->OK && $ApiResponse->ServicePayload !=null && !empty($ApiResponse->ServicePayload))
            {
                $returnObj["status"] = true;
                $returnObj["data"] = $ApiResponse->ServicePayload;;
            }else{
                $returnObj["status"] = false;
                $returnObj["data"] = null;
                $returnObj["msg"] = $ApiResponse->ErrorMessage;
            }
        }
        else{
            //log file
            //$error = "Get: {DATA}".($memberCode)."\n {RESPONSE}".json_encode($ApiResponse);
            //ApiDebug($error);
            $returnObj["status"] = false;
            $returnObj["data"] = null;
            $returnObj["msg"] = "unble to get our server!";
        }
        return (object)$returnObj;   
    }
        
    function Post($data)
    {
        global $MEMBERSHIP_REPOSITORY;
        $data = $this->FilterPostData($data);
        
        $ApiResponse = $MEMBERSHIP_REPOSITORY->Post($data);
        pre($ApiResponse);
        die;

       
      
        $returnObj = array();   
        if($ApiResponse!=null)
        {
            if($ApiResponse->StatusCode==Enum::HttpStatus()->StatusCode->OK && $ApiResponse->ServicePayload !=null && !empty($ApiResponse->ServicePayload))
            {
                $returnObj["status"] = true;
                $returnObj["data"] = $ApiResponse->ServicePayload;
            }else{
                //log file
                $error = "POST: {DATA}".($data)."\n {RESPONSE}".json_encode($ApiResponse);
                ApiDebug($error);
                $returnObj["status"] = false;
                $returnObj["data"] = null;
                $returnObj["msg"] = $ApiResponse->ErrorMessage;
            }
        }
        else{
            //log file
            $error = "POST: {DATA}".($data)."\n {RESPONSE}".json_encode($ApiResponse);
            ApiDebug($error);
            $returnObj["status"] = false;
            $returnObj["data"] = null;
            $returnObj["msg"] = "unble to get server!";
        }
        return (object)$returnObj;
    }

    function Put($data)
    {
        global $MEMBERSHIP_REPOSITORY;
        $data = $this->FilterPostData($data);
        $ApiResponse = $MEMBERSHIP_REPOSITORY->Put($data);  
        $returnObj = array();   
        if($ApiResponse!=null)
        {
            if($ApiResponse->StatusCode==Enum::HttpStatus()->StatusCode->OK && $ApiResponse->ServicePayload !=null && !empty($ApiResponse->ServicePayload))
            {
                $returnObj = array("Id"=>true);
                $returnObj["status"] = true;
                $returnObj["data"] = true;
            }else{
                //log file
                $error = "PUT: {DATA}".($data)."\n {RESPONSE}".json_encode($ApiResponse);
                ApiDebug($error);
                $returnObj["status"] = false;
                $returnObj["data"] = null;
                $returnObj["msg"] = $ApiResponse->ErrorMessage;
            }
        }
        else{
            //log file
            $error = "PUT:  {DATA}".($data)."\n {RESPONSE}".json_encode($ApiResponse);
            ApiDebug($error);
            $returnObj["status"] = false;
            $returnObj["data"] = null;
            $returnObj["msg"] = "unble to get server!";
        }
        return (object)$returnObj;   
    }
}
$MEMBERSHIP_CONTROLLER = new MemberShipController();