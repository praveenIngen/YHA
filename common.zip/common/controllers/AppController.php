 <?php
/**
* 
*/
class AppController
{

}
$OBJ_APP_CONTROLLER = new  AppController();
?>